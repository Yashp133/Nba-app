(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_b741fd61.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_b741fd61.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b32a3a0a._.js",
    "static/chunks/_e77d101f._.js"
  ],
  "source": "dynamic"
});
