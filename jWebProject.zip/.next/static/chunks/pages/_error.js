__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__73499ecc._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_beb00741._.js",
  "static/chunks/[root of the server]__923cb372._.js",
  "static/chunks/pages__error_5771e187._.js",
  "static/chunks/pages__error_b831bbe0._.js"
])
