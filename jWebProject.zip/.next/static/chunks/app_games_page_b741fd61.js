(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_games_page_b741fd61.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_games_page_b741fd61.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_75d7492c._.js",
    "static/chunks/_7ae3b036._.js"
  ],
  "source": "dynamic"
});
