(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_settings_page_b741fd61.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_settings_page_b741fd61.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_08d43ef3._.js",
    "static/chunks/_22f43d34._.js"
  ],
  "source": "dynamic"
});
