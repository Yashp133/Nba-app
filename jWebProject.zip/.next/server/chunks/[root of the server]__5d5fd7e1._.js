module.exports = {

"[project]/.next-internal/server/app/api/teams/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/app/api/teams/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
async function GET(req) {
    const urlParams = new URLSearchParams(req.url.split('?')[1]);
    const teamId = urlParams.get('teamId') || 2; // Default to team ID 2 if not provided
    const apiUrl = `https://www.balldontlie.io/api/v1/games?team_ids[]=${teamId}&seasons[]=2023&per_page=3`;
    try {
        const response = await fetch(apiUrl, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${("TURBOPACK compile-time value", "01e6f8a1-e6b6-4856-b6bc-4444caaaa6dd")}`
            }
        });
        console.log("API Response Status:", response.status); // Log status code
        const contentType = response.headers.get("Content-Type");
        const responseBody = await response.text(); // Get the raw response body
        console.log("API Response Body:", responseBody); // Log the response body
        // If response is not JSON, throw an error
        if (!contentType || !contentType.includes("application/json")) {
            throw new Error("API response is not JSON");
        }
        const data = JSON.parse(responseBody); // Parse the response body as JSON
        if (data && data.data) {
            return new Response(JSON.stringify(data.data), {
                status: 200
            });
        } else {
            console.error("No valid game data found");
            return new Response(JSON.stringify({
                error: "No valid data in response"
            }), {
                status: 500
            });
        }
    } catch (err) {
        console.error("Error fetching data:", err);
        return new Response(JSON.stringify({
            error: "Error fetching data"
        }), {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__5d5fd7e1._.js.map