'use client';
import { useEffect, useState } from 'react';
import Navbar from '@/components/navbar';

export default function Home() {
  const [games, setGames] = useState([]);

  useEffect(() => {
    const fetchGames = async () => {
      const today = new Date();
      const lastWeek = new Date(today);
      lastWeek.setDate(today.getDate() - 7);
      const res = await fetch(`/api/game?start_date=${lastWeek.toISOString().split('T')[0]}&end_date=${today.toISOString().split('T')[0]}`);
      const data = await res.json();
      setGames(data || []);
    };
    fetchGames();
  }, []);

  return (
    <div className="bg-white text-black min-h-screen">
      {/* Navbar */}
      <Navbar />

      {/* Schedule ticker */}
      <div className="w-full bg-blue-100 overflow-x-auto whitespace-nowrap py-2 px-4 text-sm text-blue-800 font-medium border-b border-blue-300">
        {games.length > 0 ? (
          games.slice(0, 10).map((game, index) => (
            <span key={index} className="mr-6 inline-block">
              {game.home_team.abbreviation} vs {game.visitor_team.abbreviation} — {game.home_team_score}:{game.visitor_team_score}
            </span>
          ))
        ) : (
          <span>Loading schedule...</span>
        )}
      </div>

      {/* Hero */}
      <section className="text-center py-16 border-b border-gray-200">
        <h1 className="text-5xl font-bold text-black mb-4">🏀 NBA Central Hub</h1>
        <p className="text-lg text-gray-600 mb-6">Live scores, player stats, and headlines — all in one place</p>
        <button className="bg-red-600 text-white px-6 py-2 rounded hover:bg-blue-600 transition">Explore Now</button>
      </section>

      {/* Recent Games */}
      <section className="px-6 py-12 bg-gray-100">
        <h2 className="text-3xl font-bold mb-6">📊 Recent Games</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm bg-white shadow-md rounded-lg">
            <thead>
              <tr className="bg-blue-100 text-blue-800">
                <th className="py-3 px-4">Home Team</th>
                <th className="py-3 px-4">Visitor Team</th>
                <th className="py-3 px-4">Score</th>
                <th className="py-3 px-4">Date</th>
              </tr>
            </thead>
            <tbody>
              {games.length > 0 ? (
                games.slice(0, 5).map((game, index) => (
                  <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-2 px-4">{game.home_team.full_name}</td>
                    <td className="py-2 px-4">{game.visitor_team.full_name}</td>
                    <td className="py-2 px-4">{game.home_team_score} - {game.visitor_team_score}</td>
                    <td className="py-2 px-4">{new Date(game.date).toLocaleDateString()}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="py-6 text-center text-gray-500">Loading recent games...</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Headlines */}
      <section className="px-6 py-12">
        <h2 className="text-3xl font-bold mb-6">📰 Latest Headlines</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-100 p-4 rounded hover:shadow-lg transition">
            <img src="/news/celtics-record.jpg" alt="Celtics" className="w-full h-48 object-cover rounded" />
            <h3 className="text-lg font-semibold mt-4">Celtics break NBA 3-point record</h3>
            <p className="text-sm text-gray-600">Boston passes 2023 Warriors with 5 games left</p>
          </div>
          <div className="bg-gray-100 p-4 rounded hover:shadow-lg transition">
            <img src="/news/howard-hall.jpg" alt="Dwight Howard" className="w-full h-48 object-cover rounded" />
            <h3 className="text-lg font-semibold mt-4">Dwight Howard joins 2025 Hall of Fame</h3>
            <p className="text-sm text-gray-600">The 8-time All-Star is finally in</p>
          </div>
          <div className="bg-gray-100 p-4 rounded hover:shadow-lg transition">
            <img src="/news/jamorant.jpg" alt="Ja Morant" className="w-full h-48 object-cover rounded" />
            <h3 className="text-lg font-semibold mt-4">Ja Morant under review again</h3>
            <p className="text-sm text-gray-600">Another gun incident under NBA scrutiny</p>
          </div>
        </div>
      </section>
    </div>
  );
}
